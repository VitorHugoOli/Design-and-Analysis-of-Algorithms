#include "Sudoku.h"

int main(int argc, char** argv) {

    menuSudoku();

    return 0;
}

